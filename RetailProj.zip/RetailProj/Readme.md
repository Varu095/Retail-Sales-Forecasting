# TOPIC: Retail Sales Forecasting

## Problem Statement
Retail stores face difficulty in predicting future sales, leading to overstocking or stock shortages.

## Objective and Goal
To build a machine learning model that predicts future sales using historical data in order to overcome the stock issues.

## Solution
We developed a Retail Sales Forecasting system using:
- Random Forest Regressor
- Time-series feature engineering

## Features
- Sales prediction
- Demand spike detection
- Visualization dashboard

## Technologies Used
- Python
- Pandas
- NumPy
- Scikit-learn
- Streamlit
- Matplotlib

## Feature Engineering
- Date → day, month, year, weekday
- Lag features (previous sales)
- Rolling average (7-day)

## How to Run
1. Install dependencies:
   pip install streamlit pandas numpy scikit-learn matplotlib

2. Run the app:
   streamlit run app.py

## Output
- Predicted sales value
- Sales trend graph
- Demand spike alert

## Future Scope
- Multi-store prediction
- Real-time data integration
- Deep learning models (LSTM)

